Buenas profe,

Te he puesto una de las presentaciones en GIF y otra en vídeo.
Te dejo de todos modos el link de CANVAS por si quisieras verlo mejor.
¡Un saludo!

https://www.canva.com/design/DAF2mozJ29M/kNX8QITYO9xmyZvqE-Fm1g/view?utm_content=DAF2mozJ29M&utm_campaign=designshare&utm_medium=link&utm_source=editor